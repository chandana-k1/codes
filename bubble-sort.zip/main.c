/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,j,temp;
   scanf("%d",&n); //number of elements
    int m[n];
   for(i=0;i<n;i++)
   {
       scanf("%d",&m[i]);
   }
   for(i=0;i<n-1;i++)  //n number of times
   {
       for(j=0;j<n-i-1;j++)   //compare adjecent elements .for every j one biggest reach the end
       {
           if(m[j]>m[j+1])
           {
              temp=m[j];
              m[j]=m[j+1];
              m[j+1]=temp;
           }
       }
   }
   for(i=0;i<n;i++)
   {
       printf("%d",m[i]);
   }
    return 0;
}
