/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,n,key;
    scanf("%d",&n);//number of elements
    int m[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&m[i]);
    }
    scanf("%d",&key);
    for(i=0;i<n;i++)
    {
        if(m[i]==key)
        {
            printf("element found at index %d",i);
            break;
        }
    }
    return 0;
}

